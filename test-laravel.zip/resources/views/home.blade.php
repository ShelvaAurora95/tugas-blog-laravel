@extends('layouts.main')

@section('container')
<h1>Hello, world!</h1>
@endsection